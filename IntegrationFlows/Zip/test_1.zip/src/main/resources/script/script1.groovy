import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {

    // Get body as String
    def body = message.getBody(String)

    // Parse JSON
    def json = new JsonSlurper().parseText(body)

    // Extract access token
    def accessToken = json.access_token

    if(accessToken != null && accessToken.trim() != "") {
        
        // Create Bearer token
        def bearerToken = "Bearer " + accessToken
        
        // Set Authorization header
        message.setHeader("Authorization", bearerToken)
    }

    return message
}